#!/usr/bin/env python3
"""Build a dependency-free, search-engine-readable academic website."""
import argparse
import html
import json
import os
from pathlib import Path
import shutil

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'dist'
P = json.loads((ROOT / 'data/profile.json').read_text())
PUBS = json.loads((ROOT / 'data/publications.json').read_text())
BY_ID = {p['id']: p for p in PUBS}
PRODUCTION = argparse.ArgumentParser()
PRODUCTION.add_argument('--production', action='store_true')
PRODUCTION = PRODUCTION.parse_args().production
BASE = os.environ.get('SITE_URL', P['site_url']).rstrip('/')
esc = lambda value: html.escape(str(value), quote=True)
OUT.mkdir(exist_ok=True)
for asset in (ROOT / 'assets').iterdir():
    if asset.is_file():
        shutil.copy2(asset, OUT / asset.name)

def link(url, label, cls=''):
    return f'<a href="{esc(url)}" class="{cls}">{label}</a>'

def socials():
    return '<div class="socials">' + ''.join([
        link('mailto:' + P['email'], 'Email <span aria-hidden="true">↗</span>'),
        link(P['scholar'], 'Google Scholar <span aria-hidden="true">↗</span>'),
        link(P['github'], 'GitHub <span aria-hidden="true">↗</span>'),
        link('cv.html', 'Curriculum vitae <span aria-hidden="true">↗</span>')]) + '</div>'

def bibtex(p):
    typ = {'journal':'article', 'conference':'inproceedings', 'manuscript':'unpublished'}[p['type']]
    authors = p['authors'].replace(', and ', ', ').replace(', ', ' and ')
    fields = [('title', '{' + p['title'] + '}'), ('author', authors), ('year', str(p['year']))]
    if p['type'] != 'manuscript':
        fields.append(('journal' if p['type'] == 'journal' else 'booktitle', p['venue']))
    for key in ['volume', 'number', 'pages', 'doi']:
        if p.get(key): fields.append((key, p[key].replace('–', '--')))
    if p['status'] != 'Published':
        fields.append(('note', p['status'] + ('; ' + p['venue'] if p['type'] == 'manuscript' else '')))
    return '@' + typ + '{' + p['id'] + ',\n' + ',\n'.join('  ' + k + ' = {' + v.replace('&', '\\&') + '}' for k, v in fields) + '\n}'

def paper(p, summary=False):
    url = 'https://doi.org/' + p['doi'] if p['doi'] else ''
    title = link(url, esc(p['title'])) if url else esc(p['title'])
    authors = esc(p['authors']).replace('Y. Pei', '<strong>Y. Pei</strong>')
    citation = esc(p['venue'])
    if p.get('volume'): citation += ', ' + esc(p['volume'])
    if p.get('number'): citation += '(' + esc(p['number']) + ')'
    if p.get('pages'): citation += ', ' + esc(p['pages'])
    citation += ' · ' + str(p['year'])
    status = ''
    if p['status'] != 'Published':
        cls = 'review' if p['status'] == 'Under review' else 'accepted'
        status = f'<span class="tag {cls}">{esc(p["status"])}</span>'
    actions = (link(url, 'DOI ↗') if url else '')
    if p.get('pdf'): actions += link(p['pdf'], 'Author manuscript ↗')
    if p.get('award'): actions += f'<span class="award">{esc(p["award"])}</span>'
    synopsis = f'<p class="pub-summary">{esc(p["summary"])}</p>' if summary and p.get('summary') else ''
    search_text = ' '.join([p['title'], p['authors'], p['venue'], p['status'], str(p['year'])]).lower()
    return f'''<article class="publication" id="{p['id']}" data-paper data-type="{p['type']}" data-year="{p['year']}" data-search="{esc(search_text)}">
    <div class="pub-year">{p['year']}</div><div><h3>{title}</h3><p class="authors">{authors}</p><p class="venue">{citation}</p>{status}{synopsis}
    <div class="pub-links">{actions}</div><details class="citation"><summary>BibTeX</summary><pre id="bib-{p['id']}">{esc(bibtex(p))}</pre><button class="copy" data-copy="bib-{p['id']}" aria-live="polite">Copy citation</button></details></div></article>'''

def heading(kicker, title, description):
    return f'<header class="page-top"><p class="eyebrow">{kicker}</p><h1>{title}</h1><p class="lead">{description}</p></header>'

def linked_bio(text):
    return esc(text).replace('Junbo Zhao', link(P['advisor_url'], 'Junbo Zhao'))

def timeline(items):
    return ''.join(f'''<div class="timeline-item"><div class="date">{esc(x['date'])}</div><div><h3>{esc(x['title'])}</h3><p class="place">{esc(x['place'])}</p>{'<p class="detail">' + linked_bio(x['detail']) + '</p>' if x.get('detail') else ''}</div></div>''' for x in items)

def write_page(filename, title, description, content, current='', lang='en'):
    nav = [('index.html','About'),('research.html','Research'),('publications.html','Publications'),('materials.html','Resources'),('cv.html','CV')]
    nav_html = ''.join(f'<a href="{url}"' + (' aria-current="page"' if current == label else '') + f'>{label}</a>' for url, label in nav)
    nav_html += link('index.html' if lang == 'zh-CN' else 'zh.html', 'EN' if lang == 'zh-CN' else '中文')
    canonical = BASE + ('/' if filename == 'index.html' else '/' + filename)
    person = {'@context':'https://schema.org', '@type':'ProfilePage', 'dateModified':P['updated'], 'url':canonical,
        'mainEntity':{'@type':'Person', '@id':BASE+'/#person', 'name':P['name'], 'url':BASE+'/', 'image':BASE+'/portrait.jpg',
        'jobTitle':P['role'], 'description':P['intro'], 'email':P['email'],
        'worksFor':{'@type':'CollegeOrUniversity','name':P['institution']},
        'alumniOf':[{'@type':'CollegeOrUniversity','name':n} for n in ['University of Connecticut','Lehigh University','University of Minnesota Twin Cities']],
        'sameAs':[P['scholar'],P['github'],P['linkedin'],P['lab_url']]}}
    ld = json.dumps(person,ensure_ascii=False).replace('<','\\u003c')
    alternates = ''
    if filename in ['index.html','zh.html']:
        alternates = f'<link rel="alternate" hreflang="en" href="{BASE}/"><link rel="alternate" hreflang="zh-CN" href="{BASE}/zh.html"><link rel="alternate" hreflang="x-default" href="{BASE}/">'
    robots = 'index,follow,max-image-preview:large' if PRODUCTION and filename != '404.html' else 'noindex,nofollow'
    rendered = f'''<!doctype html>
<html lang="{lang}"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>{esc(title)}</title><meta name="description" content="{esc(description)}"><meta name="author" content="Yansong Pei"><meta name="robots" content="{robots}">
<link rel="canonical" href="{canonical}">{alternates}<link rel="icon" href="favicon.svg" type="image/svg+xml"><link rel="stylesheet" href="style.css">
<meta property="og:type" content="website"><meta property="og:title" content="{esc(title)}"><meta property="og:description" content="{esc(description)}"><meta property="og:url" content="{canonical}"><meta property="og:image" content="{BASE}/portrait.jpg"><meta property="og:image:alt" content="Portrait of Yansong Pei"><meta name="twitter:card" content="summary"><meta name="theme-color" content="#244e70">
<script type="application/ld+json">{ld}</script><script src="site.js" defer></script></head><body>
<a class="skip" href="#main">Skip to content</a><header class="site-header"><div class="container header-inner"><a class="brand" href="index.html"><span class="monogram" aria-hidden="true">YP</span>Yansong Pei</a><button class="menu-toggle" aria-controls="navigation" aria-expanded="false">Menu</button><nav class="nav" id="navigation" aria-label="Main navigation">{nav_html}</nav></div></header>
<main class="container" id="main">{content}</main>
<footer class="site-footer"><div class="container footer-inner"><div>© 2026 Yansong Pei <span aria-hidden="true">·</span> Michigan State University</div><div>{link('mailto:'+P['email'],P['email'])} <span aria-hidden="true">·</span> Updated October 2026</div></div></footer></body></html>'''
    (OUT/filename).write_text(rendered,encoding='utf-8')

research_teasers = ''.join(f'''<article class="research-teaser"><span class="number">{x['number']}</span><div><h3>{link('research.html#'+x['id'],esc(x['title'])+' <span aria-hidden="true">↗</span>')}</h3><p>{esc(x['summary'])}</p></div></article>''' for x in P['projects'][:4])
home = f'''<section class="hero"><div><p class="eyebrow">AI for resilient energy systems</p><h1>Yansong Pei<span class="small" style="letter-spacing:0;margin-left:12px">Ph.D.</span></h1><p class="role"><strong>{esc(P['role'])}</strong><br>{esc(P['department'])}<br>{esc(P['institution'])}</p><p class="intro">{esc(P['intro'])}</p>{socials()}<p class="academic-link">Ph.D. advisor: {link(P['advisor_url'],'Junbo Zhao')}<br>{link(P['doctoral_lab_url'],'CREATE Lab ↗')} <span class="muted">· Doctoral research</span></p></div><figure class="portrait-wrap"><img class="portrait" src="portrait.jpg" width="1065" height="1600" fetchpriority="high" alt="Yansong Pei"><figcaption>East Lansing, Michigan</figcaption></figure></section>
<section class="section about-grid" aria-labelledby="about-title"><div><p class="eyebrow" id="about-title">A little about me</p></div><div class="prose"><p>{esc(P['bio'])}</p><p>{linked_bio(P['background'])}</p><div class="lab-links"><div><span>Doctoral research</span>{link(P['doctoral_lab_url'],'CREATE Lab · Junbo Zhao ↗')}</div><div><span>Current appointment</span>{link(P['lab_url'],'E-RESILIENCY Laboratory ↗')}</div></div></div></section>
<section class="section"><div class="section-heading"><h2>Research directions</h2>{link('research.html','Explore my research ↗')}</div><div class="research-overview">{research_teasers}</div></section>
<section class="section"><div class="section-heading"><h2>Selected publications</h2>{link('publications.html','All publications ↗')}</div>{''.join(paper(x,True) for x in PUBS if x.get('selected'))}</section>
<section class="section about-grid"><div><p class="eyebrow">From research to practice</p><h2>BreakerWise</h2></div><div class="prose"><p>Alongside my research on grid control, I work on AI-enabled circuit monitoring and diagnostics. BreakerWise connects embedded sensing, waveform analytics, and equipment-health insights to practical needs in farms and production facilities.</p>{link('research.html#breakerwise','Discover the project ↗','small')}<p class="small muted" style="margin-top:18px">Product Development Lead · Venture Fellow · MTRAC AgBio</p></div></section>
<section class="contact"><div><h2>Let’s connect.</h2><p>For research, collaboration, and academic inquiries.</p></div>{link('mailto:'+P['email'],P['email']+' ↗','button')}</section>'''
write_page('index.html','Yansong Pei | AI for Power & Energy Systems',P['intro']+' Postdoctoral Research Associate at Michigan State University.',home,'About')

projects = ''
for x in P['projects']:
    related = ''.join('<li>'+link('publications.html#'+pid,esc(BY_ID[pid]['title']))+'</li>' for pid in x['papers'])
    refs = '<p class="subheading">Related publications</p><ul class="related">'+related+'</ul>' if related else ''
    external = link(x['link'],x['link_label']+' ↗','small') if x.get('link') else ''
    if x['id'] == 'der-control': external = '<p>' + link(P['doctoral_lab_url'], 'CREATE Lab · Ph.D. advisor Junbo Zhao ↗') + '</p>'
    projects += f'''<section class="project" id="{x['id']}"><aside class="project-aside"><span class="number">{x['number']}</span><p>{x['period']}</p><span class="tag">{x['status']}</span></aside><div><h2>{esc(x['title'])}</h2><p>{esc(x['detail'])}</p><div class="tags">{''.join('<span class="tag">'+esc(tag)+'</span>' for tag in x['tags'])}</div>{refs}{external}</div></section>'''
research = heading('Research','Intelligence for a<br>more resilient grid.','My work connects learning algorithms with physical models, operational constraints, and practical energy-system applications.') + projects
research += '''<section class="section"><div class="section-heading"><h2>Earlier engineering work</h2></div><div class="teaching"><article><h3>Embedded current monitoring</h3><p>ESP32-based current sensing, calibration, visualization, and data logging, with exploration of TinyML for load classification and anomaly detection (2025).</p></article><article><h3>High-wattage heater control</h3><p>Undergraduate senior design work on a temperature-control and display unit, combining sensors, feedback control, embedded programming, and PCB prototyping (2017–2018).</p></article></div></section><section class="statement"><h2>Looking ahead</h2><p>My long-term research vision is to bring interpretable, robust, and scalable learning into energy infrastructure—combining physical constraints, coordinated control, and realistic validation.</p></section>'''
write_page('research.html','Research | Yansong Pei','Research on safe reinforcement learning, BESS, data-center grid integration, DER control, climate resilience, and embedded circuit intelligence.',research,'Research')

years = sorted({p['year'] for p in PUBS},reverse=True)
toolbar = '<div class="toolbar no-print"><div class="search-group"><label for="paper-search">SEARCH PUBLICATIONS</label><input type="search" id="paper-search" placeholder="Title, author, venue, or keyword…"></div><div class="filter-group"><label for="paper-type">TYPE</label><select id="paper-type"><option value="">All types</option><option value="journal">Journal articles</option><option value="conference">Conference papers</option></select></div><div class="filter-group"><label for="paper-year">YEAR</label><select id="paper-year"><option value="">All years</option>'+''.join(f'<option>{y}</option>' for y in years)+'</select></div></div>'
publications = heading('Publications','Papers & manuscripts.','Research in power-system control, reinforcement learning, energy storage, and resilience. Accepted work is explicitly labeled.')
publications += '<div class="socials">'+link(P['scholar'],'Google Scholar ↗')+link('publications.bib','Download all BibTeX ↓')+'</div>'+toolbar
publications += f'<p class="result-count" id="paper-count" aria-live="polite">{len(PUBS)} of {len(PUBS)} records</p>' + ''.join(paper(x) for x in PUBS)
publications += '<p class="empty" id="empty-results" hidden>No publications match these filters. Try a different keyword or select all types and years.</p>'
write_page('publications.html','Publications | Yansong Pei','Journal articles, conference papers, and manuscripts by Yansong Pei, with DOI links, author manuscripts, and BibTeX citations.',publications,'Publications')

cv = heading('Curriculum vitae','Academic journey.','Yansong Pei, Ph.D. · Postdoctoral Research Associate<br>Electrical and Computer Engineering · Michigan State University')
cv += '<p class="no-print"><button class="button" data-print>Print / save as PDF ↓</button></p>'
for title, key in [('Appointments','appointments'),('Education','education'),('Fellowships & honors','awards')]:
    cv += '<section class="cv-section"><h2>'+title+'</h2>'+timeline(P[key])+'</section>'
cv += '''<section class="cv-section"><h2>Research translation</h2>'''+timeline([{'date':'2025–2026','title':'BreakerWise · MTRAC AgBio','place':'Michigan State University','detail':'Lead Technical Researcher and Product Development Lead. AI-enabled circuit sensing, diagnostics, and embedded prototyping; supported by the Michigan Translational Research and Commercialization program.'}])+'''</section><section class="cv-section"><h2>Teaching & mentoring</h2>'''+timeline([{'date':'2026','title':'Instructor · Grid School 1','place':'Institute of Public Utilities, Michigan State University','detail':'Engineering, Economics, and Modeling Fundamentals. Professional instruction on AI applications in power systems for participants from utilities, regulatory agencies, and industry.'},{'date':'2025–present','title':'Graduate Research Mentor','place':'E-RESILIENCY Laboratory','detail':'Mentoring in research design, power-system modeling, simulation, optimization, machine learning, and scholarly communication.'}])+'''</section><section class="cv-section"><h2>Professional service</h2><p>Ad hoc journal reviewer for venues including <em>Applied Energy</em>, <em>IEEE Transactions on Smart Grid</em>, <em>IEEE Transactions on Sustainable Energy</em>, <em>IEEE Transactions on Industrial Informatics</em>, <em>IEEE Open Access Journal of Power and Energy</em>, and <em>International Journal of Electrical Power & Energy Systems</em>.</p><p>Conference reviewer: IEEE Power & Energy Society General Meeting, 2025. Member of IEEE.</p></section><section class="cv-section"><h2>Technical expertise</h2><p><strong>AI and control:</strong> safe, multi-agent, and hierarchical reinforcement learning; surrogate modeling; graph neural networks; uncertainty-aware learning.</p><p><strong>Power systems:</strong> OpenDSS, ANDES, RTDS/RSCAD, MATLAB, distribution-system operation, frequency response, and BESS/DER coordination.</p><p><strong>Implementation:</strong> Python, MATLAB, C, PyTorch, TensorFlow, Stable-Baselines3, RLlib, ESP32, STM32, TinyML, Altium, and PCB prototyping.</p></section><section class="cv-section cv-publications"><h2>Publications</h2>'''+''.join(paper(x) for x in PUBS)+'</section>'
write_page('cv.html','Curriculum Vitae | Yansong Pei','Academic appointments, education, fellowships, teaching, professional service, and publications of Yansong Pei.',cv,'CV')

materials = heading('Research resources','Read. Explore. Connect.','An entry point to research papers, the doctoral research program, teaching, and technology translation.')
materials += '''<section class="section"><h2>Papers & citations</h2>'''
for p in PUBS:
    if p.get('pdf'):
        materials += f'<article class="resource"><span class="format">MANUSCRIPT</span><div><h3>{esc(p["title"])}</h3><p>{esc(p["venue"])} · {p["year"]}. Public author manuscript hosted by a research repository.</p></div>{link(p["pdf"],"Read PDF ↗")}</article>'
materials += '<article class="resource"><span class="format">BIBTEX</span><div><h3>Publication bibliography</h3><p>Download the full citation collection, with publication status retained for accepted work.</p></div>'+link('publications.bib','Download ↓')+'</article></section>'
materials += '''<section class="section" id="doctoral-research"><p class="eyebrow">Doctoral research · University of Connecticut</p><h2>Robust deep reinforcement learning<br>for distribution systems.</h2><div class="prose"><p>My dissertation studies distribution-system operation and control with distributed energy resources through three connected themes: voltage safety, operating flexibility, and economic operation.</p><p>The research progresses from multi-agent PV-inverter coordination and topology-aware control to limited-observability learning, PV–BESS coordination, and hierarchical HVAC control. The associated papers document the methods and evaluations.</p>'''+link('research.html#der-control','Explore the research and associated papers ↗')+'''</div></section><section class="section"><p class="eyebrow">Teaching & knowledge exchange</p><h2>AI applications in power systems.</h2><div class="teaching"><article><h3>Professional instruction</h3><p>My Grid School teaching connects core AI techniques with applications across generation, transmission, distribution, and system operation. Topics include implementation challenges, industry tools, and the grid implications of AI data centers.</p></article><article><h3>Graduate mentoring</h3><p>I mentor graduate researchers in modeling, simulation, machine learning, research design, technical writing, and conference preparation.</p>'''+link('mailto:'+P['email'],'Contact me about teaching materials ↗','small')+'''</article></div></section><section class="section"><p class="eyebrow">Research in the world</p><h2>BreakerWise at MSU.</h2><div class="prose"><p>Learn how AI-driven circuit monitoring, fault analysis, and circuit-health assessment are moving from research toward practical applications.</p>'''+link('https://innovationcenter.msu.edu/msus-mtrac-program-creates-solutions/','Read the MSU Innovation Center feature ↗')+'</div></section>'
write_page('materials.html','Research Resources | Yansong Pei','Open author manuscripts, BibTeX, doctoral research overview, AI power-system teaching, and BreakerWise research translation.',materials,'Resources')

zh = heading('中文简介','Yansong Pei','密歇根州立大学 · 电气与计算机工程系 · 博士后研究员')
zh += f'''<div class="zh-copy"><p>我的研究聚焦于人工智能与电力能源系统的交叉领域，探索如何将强化学习、物理模型和嵌入式智能用于电网运行与控制、分布式能源协调、电池储能和系统韧性提升。</p><p>目前，我在密歇根州立大学 E-RESILIENCY 实验室开展博士后研究，并参与 BreakerWise 项目，将电气传感、波形分析和人工智能诊断方法转化为实际的电路监测与设备健康分析技术。</p><h2>学术经历</h2><p>我于 2024 年获得康涅狄格大学电气工程博士学位，导师为 {link(P['advisor_url'],'Junbo Zhao')}，博士阶段的研究在 {link(P['doctoral_lab_url'],'CREATE Lab')} 开展。此前，我在 Lehigh University 获得硕士学位，并通过北京交通大学与明尼苏达大学双城分校的 2+2 项目完成本科学习。2023 年夏季，我曾在美国国家可再生能源实验室（NREL）开展研究实习。</p><h2>研究方向</h2><ul><li>安全强化学习与分布式电池储能协调</li><li>AI 数据中心并网、故障穿越与频率支撑</li><li>配电网电压控制、分布式能源与 HVAC 柔性调控</li><li>气候影响下的电网韧性与储能调度</li><li>嵌入式传感、波形分析和电路智能诊断</li></ul><p>{link('research.html','查看研究项目 →')} &nbsp; {link('publications.html','查看全部论文 →')}</p><h2>联系</h2><p>{link('mailto:'+P['email'],P['email'])}<br>{link(P['scholar'],'Google Scholar')} · {link(P['github'],'GitHub')}</p></div>'''
write_page('zh.html','中文简介 | Yansong Pei','Yansong Pei：密歇根州立大学博士后研究员，研究人工智能、电力系统、强化学习、储能、电网韧性与嵌入式电路诊断。',zh,lang='zh-CN')
write_page('404.html','Page not found | Yansong Pei','Return to Yansong Pei’s academic homepage.',heading('404','Page not found.','This page may have moved. Explore the research or return to the homepage.')+'<p>'+link(BASE+'/','Back to the homepage →','button')+'</p>')
(OUT/'publications.bib').write_text('\n\n'.join(bibtex(x) for x in PUBS)+'\n')
(OUT/'.nojekyll').write_text('')
pages = ['','research.html','publications.html','materials.html','cv.html','zh.html']
(OUT/'sitemap.xml').write_text('<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">'+''.join(f'<url><loc>{esc(BASE)}/{p}</loc><lastmod>{P["updated"]}</lastmod></url>' for p in pages)+'</urlset>')
(OUT/'robots.txt').write_text('User-agent: *\n'+('Allow: /\nSitemap: '+BASE+'/sitemap.xml\n' if PRODUCTION else 'Disallow: /\n'))
print(f'Built {len(pages)} pages + 404, bibliography, sitemap, and assets in {OUT} ({"production" if PRODUCTION else "preview"}).')
