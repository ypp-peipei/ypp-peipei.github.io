#!/usr/bin/env python3
"""Validate the generated site's links, accessibility basics, and bibliography."""
from html.parser import HTMLParser
from pathlib import Path
from urllib.parse import urlsplit, unquote
import json
import re
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'dist'
errors = []

class Page(HTMLParser):
    def __init__(self, path):
        super().__init__()
        self.path, self.ids, self.links, self.h1, self.canonical = path, set(), [], 0, 0
    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        if a.get('id'):
            if a['id'] in self.ids: errors.append(f'{self.path.name}: duplicate id {a["id"]}')
            self.ids.add(a['id'])
        if tag == 'h1': self.h1 += 1
        if tag == 'link' and a.get('rel') == 'canonical': self.canonical += 1
        if tag == 'img' and not a.get('alt'): errors.append(f'{self.path.name}: missing image alt text')
        for attr in ('href','src'):
            if a.get(attr): self.links.append(a[attr])

pages = {}
for path in OUT.glob('*.html'):
    p = Page(path)
    text = path.read_text()
    p.feed(text)
    pages[path.name] = p
    if p.h1 != 1 or p.canonical != 1: errors.append(f'{path.name}: expected one h1 and canonical URL')
    for ld in re.findall(r'<script type="application/ld\+json">(.*?)</script>',text,re.S): json.loads(ld)
    if 'drive.google.com' in text or '612-517' in text: errors.append(f'{path.name}: private source or phone leaked')

for p in pages.values():
    for url in p.links:
        part = urlsplit(url)
        if part.scheme or part.netloc: continue
        target = unquote(part.path) or p.path.name
        if not (OUT / target).is_file(): errors.append(f'{p.path.name}: missing file {url}')
        if part.fragment and target in pages and part.fragment not in pages[target].ids:
            errors.append(f'{p.path.name}: missing anchor {url}')

pubs = json.loads((ROOT/'data/publications.json').read_text())
assert len({p['id'] for p in pubs}) == len(pubs), 'Duplicate publication identifiers'
for p in pubs:
    if p['id'] not in pages['publications.html'].ids: errors.append('Missing publication '+p['id'])
    if p['status'] == 'Published' and not p['doi']: errors.append('Published paper lacks DOI: '+p['id'])
ET.parse(OUT/'sitemap.xml')
if errors: raise SystemExit('\n'.join(errors))
print(f'PASS: {len(pages)} HTML pages, all internal links/anchors, structured metadata, {len(pubs)} publications, sitemap, and source privacy checks.')
