#!/usr/bin/env python3
"""Bundle only editable public website source, excluding private working notes."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
root=Path(__file__).resolve().parents[1]
with ZipFile(root/'dist/website-source.zip','w',ZIP_DEFLATED) as z:
    for pattern in ['assets/*','data/*.json','scripts/*.py','.github/workflows/*.yml']:
        for p in root.glob(pattern):
            if p.is_file(): z.write(p,p.relative_to(root))
    for p in ['README.md','.gitignore']: z.write(root/p,p)
print('Packaged public editable source in dist/website-source.zip')
