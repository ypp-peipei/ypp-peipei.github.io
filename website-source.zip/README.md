# Yansong Pei — academic website

An original, responsive static academic website prepared for `ypp-peipei.github.io`.

## Update and preview

Edit `data/profile.json` for biography, education, and projects; edit `data/publications.json` for publications. The pages contain static HTML so the academic content is readable without JavaScript.

```sh
python3 scripts/build.py
python3 scripts/check.py
python3 -m http.server 8765 --bind 127.0.0.1 --directory dist
```

Preview builds carry `noindex` and disallow crawling. Build the public version before deployment:

```sh
python3 scripts/build.py --production
python3 scripts/check.py
```

## GitHub Pages

The full source can be deployed through the included `.github/workflows/pages.yml`: push to `main`, then select **GitHub Actions** in Settings → Pages.

Alternatively, upload the flat contents of `dist/` to the repository root and choose **Deploy from a branch → main → /(root)**. This is the browser-upload deployment route. Never upload the project root wholesale; `private-review/` contains private source references and is excluded from Git and generated output.

The deployment includes canonical URLs, a sitemap, robots.txt, ProfilePage/Person structured data, social-sharing metadata, a Chinese introduction, a print-friendly CV, publication filters, and BibTeX downloads. No analytics or third-party scripts are included.

## Content sources

Biography, projects, education, and publication records were assembled from the user's September 2026 academic CV and research materials, with checks against the MSU laboratory website, Google Scholar, and selected publisher records. Published, accepted, and under-review work are separate statuses. Do not promote a manuscript to published without its publication record.

Only public research-repository PDFs are linked. Original slide decks with presenter notes, raw research data, private Drive files, and the CV's personal telephone number are not in the published package. Resources currently include paper manuscripts, BibTeX, doctoral research and teaching summaries, and a public MSU BreakerWise feature. More downloadable research files can be added once the intended public versions are available.

## Search discovery

After deployment, verify the URL-prefix property in Google Search Console, submit `sitemap.xml`, and request homepage indexing. Add the homepage URL to Google Scholar and institutional profiles. These actions help discovery; inclusion and ranking remain Google's decisions.

## References considered

- [Academic Pages](https://academicpages.github.io/): traditional academic structure.
- [al-folio](https://alshedivat.github.io/al-folio/): publications and research portfolio.
- [GitHub Pages](https://docs.github.com/en/pages/getting-started-with-github-pages/what-is-github-pages).
- [Google indexing guidance](https://developers.google.com/search/docs/crawling-indexing/ask-google-to-recrawl).

The layout and code in this project are original; no theme source was copied. The supplied portrait remains the user's asset.
